from setuptools import setup, find_packages

setup(
    name = 'ab-ble-gateway-sdk-python',
    version = '0.0.1',
    keywords = ('ab', 'ble','gateway'),
    description = 'ab ble gatwway sdk',
    license = 'Apache-v2.0',
    author = 'jingzhixiang',
    author_email = '945627077@qq.com',
    
    packages = find_packages(),
    platforms = 'any',
)
